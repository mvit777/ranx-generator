<?php
namespace Ranxerox\Bogus\Block;

class Index extends \Magento\Framework\View\Element\Template{
		
	/*public function doSomtething(){
		return $this->getData();
	}*/
}